package ru.demo.tradeapp.repository;

import ru.demo.tradeapp.models.Role;

public class RoleDao extends BaseDao<Role> {
    public RoleDao() {
        super(Role.class);
    }
}
