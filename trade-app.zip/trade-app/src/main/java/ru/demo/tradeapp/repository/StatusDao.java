package ru.demo.tradeapp.repository;

import ru.demo.tradeapp.models.Status;

public class StatusDao extends BaseDao<Status> {
    public StatusDao() {
        super(Status.class);
    }
}
